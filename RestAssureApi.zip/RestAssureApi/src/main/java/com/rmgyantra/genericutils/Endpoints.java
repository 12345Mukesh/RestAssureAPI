package com.rmgyantra.genericutils;

public interface Endpoints 
{
  public String addProject_EP="/addProject";
	public String getproject_EP="/projects";
	public String getsingleproject_EP="/projects/{projectId}";
	public String updateproject_EP="/projects/{projectId}";
	public String deleteproject_EP="/projects/{projectId}";
	
	
	
	
}
